# vit-campus-ems
College event management is scattered across multiple channels leading to conflicts, low visibility, and inefficient resource usage. This system centralizes event and resource management.
